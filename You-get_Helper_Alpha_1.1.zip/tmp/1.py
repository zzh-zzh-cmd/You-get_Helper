import os
os.system("you-get -c D:\cookies.sqlite -o C:\\Users\\zzh\\Desktop\\you-get12.27(mini)\download --no-caption https://www.bilibili.com/video/BV1rG4y1m7P6?spm_id_from=333.1007.tianma.3-1-5.click")
