import os
os.system("you-get -c D:\cookies.sqlite -o C:\\Users\\zzh\\Desktop\\you-get12.27(mini)\download --format=dash-flv --no-caption https://www.bilibili.com/video/BV1fJ411Q71L/?spm_id_from=333.999.0.0")
