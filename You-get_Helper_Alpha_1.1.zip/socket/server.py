from socket import *
from threading import Thread
import time
import os


workpath=os.getcwd()

def jiaohu(msg1):
    client_socket.send(msg1.encode("gbk"))




def waitre():
    while True:
        with open(f'{workpath}\\regedit.flag{port1}.txt') as url_file:
            urls = url_file.read()
            url_initial_list = urls.splitlines(keepends=False)
        flag1=eval(url_initial_list[0])
        if flag1==0:
            continue
        elif flag1==1:
            break

def waitre1():
    def jiaohu(msg1):
        client_socket.send(msg1.encode("gbk"))
    while True:
        with open(f'{workpath}\\regedit.flag{port1}.txt') as url_file:
            urls = url_file.read()
            url_initial_list = urls.splitlines(keepends=False)
        flag1=eval(url_initial_list[0])
        if flag1==0:
            jiaohu("对方正在注册，请稍等")
            time.sleep(5)
        elif flag1==1:
            jiaohu("对方注册完成，请继续")
            break




def regedit():
    

    os.system(f"del {workpath}\\regedit{port}.txt")
    
    def rc():
        while True:
            a= client_socket.recv(1024)  # 最大接收1024字节
            b = a.decode("gbk")
            with open(f'{workpath}\\regedit{port}.txt','w', encoding="gbk") as file:
                file.write(b)
            with open(f'{workpath}\\regedit.flag{port}.txt','w', encoding="gbk") as file:
                file.write("1")
            print(b)
            break
    def read():
        with open(f'{workpath}\\regedit{port}.txt') as url_file:
            urls = url_file.read()
            url_initial_list = urls.splitlines(keepends=False)
        return url_initial_list[0]

    jiaohu(f"服务器：开始注册用户{port}")
    time.sleep(1)
    jiaohu("请输入昵称")
    rc()
    user=read()
    jiaohu("注册成功")
    


def wait():
    while True:
            time.sleep(1)

            with open(f'{workpath}\\flag{port1}.txt') as url_file:
                urls = url_file.read()
                url_initial_list = urls.splitlines(keepends=False)
            flag=eval(url_initial_list[0])
            if flag==0:
                continue
            else:
                break


def start():
    with open(f'{workpath}\\flag{port}.txt','w', encoding="gbk") as file:
        file.write("1")

def end():
    with open(f'{workpath}\\flag{port1}.txt','w', encoding="gbk") as file:
        file.write("0")
    



def write1(a):
    with open(f'{workpath}\\{port}.txt','w', encoding="gbk") as file:
                file.write(a)

def read1():
    with open(f'{workpath}\\{port1}.txt') as url_file:
        urls = url_file.read()
        url_initial_list = urls.splitlines(keepends=False)
    return url_initial_list[0]

def recv_data():
    while True:
        recv_data = client_socket.recv(1024)  # 最大接收1024字节
        recv_content = recv_data.decode("gbk")
        write1(recv_content)
        print(recv_content)
        start()
        if recv_content == "end":
            print("结束接收消息！")
            break
        
            
 
def send_data():
    while True:
        #msg = input(">")
        wait()
        msg=read1()
        msg=user+"说："+msg
        client_socket.send(msg.encode("gbk"))
        end()
        if msg == "end":
            print("结束发送消息！")
            break


    





if __name__ == '__main__':
    server_socket = socket(AF_INET, SOCK_STREAM)  # 建立TCP套接字
    port=int(input("请指定第一端口"))
    port1=int(input("请指定第二端口"))
    os.system(f"del {workpath}\\{port}.txt")
    with open(f'{workpath}\\{port}.txt','w', encoding="gbk") as file:
                file.write("")
    end()

    with open(f'{workpath}\\regedit.flag{port}.txt','w', encoding="gbk") as file:
        file.write("0")
    server_socket.bind(("", port))  # 本机监听8899端口
    server_socket.listen(5)
    print("等待接收连接！")
    client_socket, client_info = server_socket.accept()
    print("一个客户端建立连接成功！")
    jiaohu("欢迎使用zzh开发的qq")
    time.sleep(1)
    regedit()
    waitre1()
    with open(f'{workpath}\\regedit{port1}.txt') as url_file:
        urls = url_file.read()
        url_initial_list = urls.splitlines(keepends=False)
    user=url_initial_list[0]
        
 
    t1 = Thread(target=recv_data)
    t2 = Thread(target=send_data)
    t1.start()
    t2.start()
 
    t1.join()
    t2.join()
 
    client_socket.close()
    server_socket.close()