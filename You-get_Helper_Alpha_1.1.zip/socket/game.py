from functools import total_ordering
from this import d
import time
import os
from socket import *
from threading import Thread
workpath=os.getcwd()

def jiaohu(msg1,port):
    with open(f'{workpath}\\exchange.{port}.txt','w', encoding="gbk") as file:
                file.write(msg1)

def read():
    with open(f'{workpath}\\{port}.txt') as url_file:
        urls = url_file.read()
        url_initial_list = urls.splitlines(keepends=False)
    return url_initial_list[0]

def read1():
        with open(f'{workpath}\\regedit{port1}.txt') as url_file:
            urls = url_file.read()
            url_initial_list = urls.splitlines(keepends=False)
        return url_initial_list[0]


def waitre():
    while True:
        with open(f'{workpath}\\flag{port}.txt') as url_file:
            urls = url_file.read()
            url_initial_list = urls.splitlines(keepends=False)
        flag1=eval(url_initial_list[0])
        if flag1==0:
            continue
        elif flag1==1:
            yz=read()
            a=["1","2","3"]
            if yz in a:
                yz=eval(yz)
                break
            else:
                continue 

def waitre2():
    while True:
        with open(f'{workpath}\\flag{port1}.txt') as url_file:
            urls = url_file.read()
            url_initial_list = urls.splitlines(keepends=False)
        flag1=eval(url_initial_list[0])
        if flag1==0:
            jiaohu("对方正在思考")
            time.sleep(1)
        elif flag1==1:
            yz=read1()
            a=["1","2","3"]
            if yz in a:
                yz=eval(yz)
                break
            else:
                continue 


def wait():
    while True:
            time.sleep(1)

            with open(f'{workpath}\\flag{port1}.txt') as url_file:
                urls = url_file.read()
                url_initial_list = urls.splitlines(keepends=False)
            flag=eval(url_initial_list[0])
            if flag==0:
                continue
            else:
                break


def start():
    with open(f'{workpath}\\regedit.game{port}.txt','w', encoding="gbk") as file:
        file.write("1")

def read1():
    with open(f'{workpath}\\info.txt') as url_file:
        urls = url_file.read()
        url_initial_list = urls.splitlines(keepends=False)
    return url_initial_list



def read3(port):
    with open(f'{workpath}\\{port}.txt') as url_file:
        urls = url_file.read()
        url_initial_list = urls.splitlines(keepends=False)
    return eval(url_initial_list[0])


def game_end():
    with open(f'{workpath}\\regedit.game{port}.txt','w', encoding="gbk") as file:
        file.write("0")

def re(a):
        if a==1:
            return "剪刀"
        elif a==2:
            return "石头"
        elif a==3:
            return "布"


def game():
    def re(a):
        if a==1:
            return "剪刀"
        elif a==2:
            return "石头"
        elif a==3:
            return "布"
    jiaohu("请选择\n1.剪刀\n2.石头\n3.布")
    zj=read(port)
    df=read(port1)    
    if zj==df:
        jiaohu(f"平手，对方是{re(df)},你是{re(zj)}",port)
        jiaohu(f"平手，对方是{re(zj)},你是{re(df)}",port1)
    elif zj==1:
        if df==2:
            jiaohu(f"输了，对方是{re(df)},你是{re(zj)}",port)
            jiaohu(f"赢了，对方是{re(zj)},你是{re(df)}",port1)
        elif df==3:
            jiaohu(f"赢了，对方是{re(df)},你是{re(zj)}",port)
            jiaohu(f"输了，对方是{re(zj)},你是{re(df)}",port1)
        
    elif zj==2 :
        if df==1:
            jiaohu(f"赢了，对方是{re(df)},你是{re(zj)}",port)
            jiaohu(f"输了，对方是{re(zj)},你是{re(df)}",port1)

        elif df==3:
            jiaohu(f"输了，对方是{re(df)},你是{re(zj)}",port)
            jiaohu(f"赢了，对方是{re(zj)},你是{re(df)}",port1)
    elif zj==3 :
        if df==1:
            jiaohu(f"输了，对方是{re(df)},你是{re(zj)}",port)
            jiaohu(f"赢了，对方是{re(zj)},你是{re(df)}",port1)
        elif df==2:
            jiaohu(f"赢了，对方是{re(df)},你是{re(zj)}",port)
            jiaohu(f"输了，对方是{re(zj)},你是{re(df)}",port1)
            

def pd():
    while True:

        with open(f'{workpath}\\regedit.game{port}.txt') as url_file:
            urls = url_file.read()
            url_initial_list = urls.splitlines(keepends=False)
        a=eval(url_initial_list[0])
        with open(f'{workpath}\\regedit.game{port1}.txt') as url_file:
            urls = url_file.read()
            url_initial_list = urls.splitlines(keepends=False)
        b=eval(url_initial_list[0])
        if a==1 and b==1:
            game()
            with open(f'{workpath}\\regedit.game{port}.txt','w', encoding="gbk") as file:
                file.write("0")
            with open(f'{workpath}\\regedit.game{port}.txt','w', encoding="gbk") as file:
                file.write("0")
        else:
            continue



a=read1()
port=a[0]
port1=a[1]
pd()
